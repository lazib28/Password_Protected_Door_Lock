/*******************************************************
This program was created by the CodeWizardAVR V3.46a 
Automatic Program Generator
� Copyright 1998-2021 Pavel Haiduc, HP InfoTech S.R.L.
http://www.hpinfotech.ro

Project : 
Version : 
Date    : 11/26/2021
Author  : 
Company : 
Comments: 


Chip type               : ATmega32
Program type            : Application
AVR Core Clock frequency: 16.000000 MHz
Memory model            : Small
External RAM size       : 0
Data Stack size         : 512
*******************************************************/

#include <mega32.h>

// Alphanumeric LCD functions
#include <alcd.h>



void main(void)
{
/*PB4 to PB7 has been initialized as o/p whilst PB0 to PB3 has been initialized as i/p*/
DDRB=0b11110000;

// Alphanumeric LCD initialization
// Connections are specified in the
// Project|Configure|C Compiler|Libraries|Alphanumeric LCD menu:
// RS: PORTA Bit 0
// RD: PORTA Bit 1
// EN: PORTA Bit 2
// D4: PORTA Bit 4
// D5: PORTA Bit 5
// D6: PORTA Bit 6
// D7: PORTA Bit 7
// Characters/line: 16
/* 1cd initialization*/
lcd_init(16);

while (1)
      {
     
         
         /*PB4 will send 0 to activate left most column*/
        PORTB=0b11101111;
       /* then PB0 to PB3 will check for "0" as a reading*/
       /* if they find 0 as a reading that means that key has been pressed*/
      /* then using the lcd_gotoxy() and lcd_putsf() function the corresponding line will be printed at the bottom line of the lcd*/ 
        if (PINB.0==0)
        { 
        /* the display needs to be cleared of any old lines which were printed before*/ 
        lcd_clear();
        lcd_gotoxy(0,1);
        lcd_putsf("DIVIDE");
        }
        else if (PINB.1==0)
        { 
        lcd_clear();
        lcd_gotoxy(0,1);
        lcd_putsf("MULTIPLY");
        }
        else if (PINB.2==0) 
        {
               lcd_clear(); 
        lcd_gotoxy(0,1);
        lcd_putsf("SUBTRACT");
        }
        else if (PINB.3==0)
        {    
               lcd_clear();
        lcd_gotoxy(0,1);
        lcd_putsf("PLUS"); 
        }
        
        /* same process repeats for all the other columns*/
        
        PORTB=0b11011111;
         
        if (PINB.0==0)
        { 
        lcd_clear();
        lcd_gotoxy(0,1);
        lcd_putsf("NINE");
        }
        else if (PINB.1==0)
        {
        lcd_clear();
        lcd_gotoxy(0,1);
        lcd_putsf("SIX");
        }
        else if (PINB.2==0)    
        {
        lcd_clear(); 
        lcd_gotoxy(0,1);
        lcd_putsf("THREE"); 
        }
        else if (PINB.3==0) 
        { 
        lcd_clear();
        lcd_gotoxy(0,1);
        lcd_putsf("EQUAL"); 
        }
        
        PORTB=0b10111111;
   
        if (PINB.0==0)
        { 
         lcd_clear(); 
          lcd_gotoxy(0,1);
        lcd_putsf("EIGHT");
        }
        else if (PINB.1==0)
        {
         lcd_clear();
          lcd_gotoxy(0,1);
        lcd_putsf("FIVE");
       }
        else if (PINB.2==0)
        { 
         lcd_clear();
          lcd_gotoxy(0,1);
        lcd_putsf("TWO");
        }
        else if (PINB.3==0) 
        {
         lcd_clear();
          lcd_gotoxy(0,1);
        lcd_putsf("ZERO"); 
        }
                             
        PORTB=0b01111111;
        
        if (PINB.0==0)
        {
         lcd_clear(); 
          lcd_gotoxy(0,1);
        lcd_putsf("SEVEN");  
        }
        else if (PINB.1==0)
        {
         lcd_clear();
          lcd_gotoxy(0,1);
        lcd_putsf("FOUR");
        }
        else if (PINB.2==0) 
        {
         lcd_clear();   
          lcd_gotoxy(0,1);
        lcd_putsf("ONE");
        }
        else if (PINB.3==0)
        {
         lcd_clear();
          lcd_gotoxy(0,1);
        lcd_putsf("ON/C");
        }

      }
}
